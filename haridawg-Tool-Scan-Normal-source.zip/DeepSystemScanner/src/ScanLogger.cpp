#include "ScanLogger.h"
#include "Util.h"

namespace dss {

namespace {
std::string Sanitize(const std::string& s) {  // chan log injection tu ten file
    std::string o = s;
    for (char& c : o) if ((unsigned char)c < 0x20 && c != '\n') c = '?';
    return o;
}
}

ScanLogger::ScanLogger(const std::wstring& logDir, uint64_t maxBytes) : dir_(logDir), maxBytes_(maxBytes) {
    path_ = dir_ + L"\\scan.log";
    if (!EnsureDir(dir_) || !Open()) {
        fileFailed_ = true;
        std::fputs("[WARN] Không ghi được file log; chỉ log ra console.\n", stderr);
    }
}

ScanLogger::~ScanLogger() { if (f_) std::fclose(f_); }

bool ScanLogger::Open() {
    f_ = _wfopen(path_.c_str(), L"ab");
    return f_ != nullptr;
}

void ScanLogger::RotateIfNeeded() {
    if (!f_) return;
    long pos = std::ftell(f_);
    if (pos < 0 || (uint64_t)pos < maxBytes_) return;
    std::fclose(f_); f_ = nullptr;
    std::wstring old = dir_ + L"\\scan.1.log";
    MoveFileExW(path_.c_str(), old.c_str(), MOVEFILE_REPLACE_EXISTING);
    if (!Open()) fileFailed_ = true;
}

void ScanLogger::Write(const std::string& line) {
    std::lock_guard<std::mutex> lk(mu_);
    std::fwrite(line.data(), 1, line.size(), stdout);
    std::fflush(stdout);
    if (sink_) sink_(line);
    if (!fileFailed_ && f_) {
        RotateIfNeeded();
        if (f_ && (std::fwrite(line.data(), 1, line.size(), f_) != line.size() || std::fflush(f_) != 0)) {
            fileFailed_ = true;  // loi ghi file khong duoc lam treo chuong trinh
            std::fputs("[WARN] Ghi log vào file thất bại, tắt log file.\n", stderr);
        }
    }
}

void ScanLogger::Log(const char* tag, const std::string& msg) {
    Write("[" + NowTime() + "] [" + tag + "] " + Sanitize(msg) + "\n");
}

void ScanLogger::Raw(const std::string& block) { Write(Sanitize(block) + "\n"); }

void ScanLogger::LogDetection(const Detection& d) {
    char num[16]; std::snprintf(num, sizeof num, "%03d", d.id);
    std::string b = std::string("\n===== DETECTION #") + num + " =====\n";
    b += "Path: " + ToUtf8(d.path) + "\n";
    b += std::string("Type: ") + VerdictName(d.verdict) + "\n";
    for (const auto& r : d.reasons) b += "Reason: " + r + "\n";
    b += "Source: " + d.source + "\n";
    b += "SHA256: " + (d.sha256.empty() ? std::string("(chưa tính)") : d.sha256) + "\n";
    b += std::string("Status: ") + StatusName(d.status) + "\n";
    Raw(b);
}

}  // namespace dss

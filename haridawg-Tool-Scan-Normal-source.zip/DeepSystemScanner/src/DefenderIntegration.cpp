#include "DefenderIntegration.h"
#include <algorithm>
#include <array>
#include <vector>

namespace dss {
namespace {

std::array<unsigned, 4> ParseVer(const std::wstring& s) {
    std::array<unsigned, 4> v{0, 0, 0, 0};
    size_t idx = 0; unsigned cur = 0; bool any = false;
    for (wchar_t c : s) {
        if (c >= L'0' && c <= L'9') { cur = cur * 10 + (c - L'0'); any = true; }
        else if (c == L'.' || c == L'-') { if (idx < 4) v[idx++] = cur; cur = 0; any = false; }
        else break;
    }
    if (any && idx < 4) v[idx] = cur;
    return v;
}

std::wstring FindMpCmdRun() {
    std::wstring pd = GetEnvW(L"ProgramData");
    if (!pd.empty()) {
        std::wstring base = pd + L"\\Microsoft\\Windows Defender\\Platform\\";
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((base + L"*").c_str(), &fd);
        std::wstring best; std::array<unsigned, 4> bestV{0, 0, 0, 0};
        if (h != INVALID_HANDLE_VALUE) {
            do {
                if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || fd.cFileName[0] == L'.') continue;
                std::wstring cand = base + fd.cFileName + L"\\MpCmdRun.exe";
                auto v = ParseVer(fd.cFileName);
                if (PathExists(cand) && (best.empty() || v > bestV)) { best = cand; bestV = v; }
            } while (FindNextFileW(h, &fd));
            FindClose(h);
        }
        if (!best.empty()) return best;
    }
    std::wstring pf = GetEnvW(L"ProgramFiles");
    if (!pf.empty()) {
        std::wstring cand = pf + L"\\Windows Defender\\MpCmdRun.exe";
        if (PathExists(cand)) return cand;
    }
    return {};
}

}  // namespace

DefenderStatus DefenderIntegration::Detect() {
    DefenderStatus st;
    st.mpCmdRun = FindMpCmdRun();
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (scm) {
        SC_HANDLE svc = OpenServiceW(scm, L"WinDefend", SERVICE_QUERY_STATUS);
        if (svc) {
            SERVICE_STATUS ss{};
            if (QueryServiceStatus(svc, &ss)) st.serviceRunning = (ss.dwCurrentState == SERVICE_RUNNING);
            else st.note = "Không truy vấn được trạng thái dịch vụ WinDefend";
            CloseServiceHandle(svc);
        } else {
            st.note = "Không mở được dịch vụ WinDefend (mã lỗi " + std::to_string(GetLastError()) + ")";
        }
        CloseServiceHandle(scm);
    } else {
        st.note = "Không kết nối được Service Control Manager";
    }
    if (st.mpCmdRun.empty()) st.note += (st.note.empty() ? "" : "; ") + std::string("Không tìm thấy MpCmdRun.exe");
    else if (!st.serviceRunning && st.note.empty()) st.note = "Dịch vụ WinDefend không chạy (có thể đang dùng AV khác)";
    st.available = !st.mpCmdRun.empty() && st.serviceRunning;
    return st;
}

DefenderResult DefenderIntegration::ScanFile(const DefenderStatus& st, const std::wstring& path,
                                             DWORD timeoutMs, std::string& detail) {
    if (!st.available) { detail = "Defender không khả dụng"; return DefenderResult::Error; }
    if (path.find(L'"') != std::wstring::npos) { detail = "Đường dẫn chứa ký tự không an toàn"; return DefenderResult::Error; }

    std::wstring cmd = L"\"" + st.mpCmdRun + L"\" -Scan -ScanType 3 -File \"" + path + L"\" -DisableRemediation";

    SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
    HANDLE rd = nullptr, wr = nullptr;
    if (!CreatePipe(&rd, &wr, &sa, 0)) { detail = "CreatePipe thất bại"; return DefenderResult::Error; }
    UniqueHandle rdH(rd), wrH(wr);
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOW si{};
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdOutput = wr;
    si.hStdError = wr;
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        detail = "CreateProcessW thất bại (mã lỗi " + std::to_string(GetLastError()) + ")";
        return DefenderResult::Error;
    }
    UniqueHandle proc(pi.hProcess), thr(pi.hThread);
    wrH.reset();  // dong dau ghi o phia cha de doc duoc EOF

    std::string out;
    auto drain = [&]() {
        DWORD avail = 0;
        while (PeekNamedPipe(rd, nullptr, 0, nullptr, &avail, nullptr) && avail > 0) {
            char buf[2048]; DWORD got = 0;
            if (!ReadFile(rd, buf, (DWORD)std::min<size_t>(sizeof buf, avail), &got, nullptr) || got == 0) break;
            if (out.size() < 65536) out.append(buf, got);  // gioi han bo nho
        }
    };
    DWORD start = GetTickCount();
    bool timedOut = false;
    for (;;) {
        DWORD w = WaitForSingleObject(proc.get(), 100);
        drain();
        if (w == WAIT_OBJECT_0) break;
        if (g_cancel || GetTickCount() - start > timeoutMs) {
            TerminateProcess(proc.get(), 1);
            WaitForSingleObject(proc.get(), 2000);
            timedOut = true;
            break;
        }
    }
    drain();
    if (timedOut) { detail = "Hết thời gian chờ hoặc bị hủy"; return DefenderResult::Timeout; }

    DWORD code = 0;
    if (!GetExitCodeProcess(proc.get(), &code)) { detail = "Không đọc được mã thoát"; return DefenderResult::Error; }
    std::string low = out;
    for (char& c : low) c = (char)std::tolower((unsigned char)c);
    if (code == 0) { detail = "MpCmdRun exit 0"; return DefenderResult::Clean; }
    // Dau ra phu thuoc ngon ngu he thong: neu khong nhan ra duoc thi coi la loi, KHONG doan.
    if (code == 2 && low.find("threat") != std::string::npos && low.find("no threats") == std::string::npos) {
        detail = "MpCmdRun exit 2, báo phát hiện mối đe dọa";
        return DefenderResult::ThreatFound;
    }
    detail = "MpCmdRun exit " + std::to_string(code) + " (không xác định được kết luận)";
    return DefenderResult::Error;
}

}  // namespace dss

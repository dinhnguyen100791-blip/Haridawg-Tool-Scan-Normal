#include "QuarantineManager.h"
#include <cstdio>
#include "Util.h"

namespace dss {

QuarantineManager::QuarantineManager(const std::wstring& dir) : dir_(dir) { EnsureDir(dir_); }

bool QuarantineManager::IsProtectedPath(const std::wstring& path) {
    std::wstring lp = ToLowerW(path);
    std::wstring win = ToLowerW(GetEnvW(L"SystemRoot"));
    if (!win.empty() && lp.compare(0, win.size() + 1, win + L"\\") == 0) return true;
    return false;
}

bool QuarantineManager::VerifyIdentity(const Detection& d, std::string& msg, std::string& hashOut) const {
    std::string err;
    if (!Sha256File(d.path, hashOut, err)) { msg = "Không xác minh được file: " + err; return false; }
    if (!d.sha256.empty() && hashOut != d.sha256) {
        msg = "SHA-256 đã thay đổi so với lúc phát hiện, từ chối thao tác (file có thể đã bị thay)";
        return false;
    }
    return true;
}

bool QuarantineManager::Quarantine(Detection& d, std::string& msg) {
    if (d.status == Status::Quarantined) { msg = "File đã ở trong khu cách ly"; return false; }
    if (IsProtectedPath(d.path)) {
        msg = "File nằm trong thư mục hệ thống Windows, không tự cách ly. Hãy xử lý bằng Microsoft Defender.";
        return false;
    }
    std::string hash;
    if (!VerifyIdentity(d, msg, hash)) { d.status = Status::ActionFailed; return false; }
    if (d.sha256.empty()) d.sha256 = hash;

    std::wstring dst = dir_ + L"\\q_" + FromUtf8(NowStamp()) + L"_" + std::to_wstring(d.id) + L".quar";
    if (!MoveFileExW(d.path.c_str(), dst.c_str(), MOVEFILE_COPY_ALLOWED | MOVEFILE_WRITE_THROUGH)) {
        msg = "MoveFileEx thất bại (mã lỗi " + std::to_string(GetLastError()) + ")";
        d.status = Status::ActionFailed;
        return false;
    }
    // Ghi metadata de co the khoi phuc thu cong
    FILE* m = _wfopen((dst + L".meta").c_str(), L"wb");
    if (m) {
        std::string t = "path=" + ToUtf8(d.path) + "\nsha256=" + d.sha256 + "\n";
        std::fwrite(t.data(), 1, t.size(), m);
        std::fclose(m);
    }
    if (PathExists(d.path) || !PathExists(dst)) {  // kiem tra ket qua thuc te
        msg = "Kiểm tra sau thao tác thất bại, trạng thái file không như mong đợi";
        d.status = Status::ActionFailed;
        return false;
    }
    d.quarantinePath = dst;
    d.status = Status::Quarantined;
    msg = "Đã cách ly vào " + ToUtf8(dst);
    return true;
}

bool QuarantineManager::Restore(Detection& d, std::string& msg) {
    if (d.status != Status::Quarantined) { msg = "File này chưa được cách ly trong phiên này"; return false; }
    if (PathExists(d.path)) { msg = "Đã có file khác tại đường dẫn gốc, không ghi đè"; return false; }
    if (!MoveFileExW(d.quarantinePath.c_str(), d.path.c_str(), MOVEFILE_COPY_ALLOWED | MOVEFILE_WRITE_THROUGH)) {
        msg = "Khôi phục thất bại (mã lỗi " + std::to_string(GetLastError()) + ")";
        return false;
    }
    DeleteFileW((d.quarantinePath + L".meta").c_str());
    if (!PathExists(d.path)) { msg = "Kiểm tra sau khôi phục thất bại"; return false; }
    d.quarantinePath.clear();
    d.status = Status::Restored;
    msg = "Đã khôi phục về " + ToUtf8(d.path);
    return true;
}

bool QuarantineManager::DeletePermanently(Detection& d, std::string& msg) {
    if (d.status == Status::Quarantined) {
        if (!DeleteFileW(d.quarantinePath.c_str())) {
            msg = "Xóa thất bại (mã lỗi " + std::to_string(GetLastError()) + ")";
            d.status = Status::ActionFailed;
            return false;
        }
        DeleteFileW((d.quarantinePath + L".meta").c_str());
        if (PathExists(d.quarantinePath)) { msg = "File vẫn còn sau khi xóa"; d.status = Status::ActionFailed; return false; }
        d.status = Status::Deleted;
        msg = "Đã xóa vĩnh viễn bản trong khu cách ly";
        return true;
    }
    if (IsProtectedPath(d.path)) {
        msg = "File nằm trong thư mục hệ thống Windows, không tự xóa. Hãy dùng Microsoft Defender.";
        return false;
    }
    std::string hash;
    if (!VerifyIdentity(d, msg, hash)) { d.status = Status::ActionFailed; return false; }
    if (!DeleteFileW(d.path.c_str())) {
        msg = "Xóa thất bại (mã lỗi " + std::to_string(GetLastError()) + ")";
        d.status = Status::ActionFailed;
        return false;
    }
    if (PathExists(d.path)) { msg = "File vẫn còn sau khi xóa"; d.status = Status::ActionFailed; return false; }
    d.status = Status::Deleted;
    msg = "Đã xóa vĩnh viễn";
    return true;
}

}  // namespace dss

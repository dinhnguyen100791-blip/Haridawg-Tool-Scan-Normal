#include "Util.h"
#include <bcrypt.h>
#include <softpub.h>
#include <wintrust.h>
#include <cstdio>
#include <vector>

namespace dss {

std::atomic<bool> g_cancel{false};

std::string ToUtf8(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return {};
    std::string s((size_t)n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}

std::wstring FromUtf8(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    if (n <= 0) return {};
    std::wstring w((size_t)n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}

std::string NowTime() {
    SYSTEMTIME t; GetLocalTime(&t);
    char b[16]; std::snprintf(b, sizeof b, "%02d:%02d:%02d", t.wHour, t.wMinute, t.wSecond);
    return b;
}

std::string NowStamp() {
    SYSTEMTIME t; GetLocalTime(&t);
    char b[32];
    std::snprintf(b, sizeof b, "%04d%02d%02d_%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    return b;
}

std::wstring ToLowerW(std::wstring s) {
    if (!s.empty()) CharLowerBuffW(&s[0], (DWORD)s.size());
    return s;
}

std::wstring GetEnvW(const wchar_t* name) {
    DWORD n = GetEnvironmentVariableW(name, nullptr, 0);
    if (n == 0) return {};
    std::wstring v(n, L'\0');
    DWORD m = GetEnvironmentVariableW(name, &v[0], n);
    v.resize(m);
    return v;
}

bool PathExists(const std::wstring& path) {
    return GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES;
}

bool EnsureDir(const std::wstring& p) {
    if (PathExists(p)) return true;
    for (size_t i = 3; i < p.size(); ++i)
        if (p[i] == L'\\') CreateDirectoryW(p.substr(0, i).c_str(), nullptr);
    CreateDirectoryW(p.c_str(), nullptr);
    return PathExists(p);
}

// ---- SHA-256 qua CNG (BCrypt, co tu Windows Vista) ----
namespace {
class Sha256Ctx {
public:
    Sha256Ctx() {
        if (BCryptOpenAlgorithmProvider(&alg_, BCRYPT_SHA256_ALGORITHM, nullptr, 0) < 0) return;
        DWORD len = 0, cb = 0;
        if (BCryptGetProperty(alg_, BCRYPT_OBJECT_LENGTH, (PUCHAR)&len, sizeof len, &cb, 0) < 0) return;
        obj_.resize(len);
        if (BCryptCreateHash(alg_, &h_, obj_.data(), len, nullptr, 0, 0) < 0) return;
        ok_ = true;
    }
    ~Sha256Ctx() {
        if (h_) BCryptDestroyHash(h_);
        if (alg_) BCryptCloseAlgorithmProvider(alg_, 0);
    }
    bool Update(const void* p, size_t n) {
        return ok_ && BCryptHashData(h_, (PUCHAR)p, (ULONG)n, 0) >= 0;
    }
    bool Final(std::string& hex) {
        UCHAR d[32];
        if (!ok_ || BCryptFinishHash(h_, d, 32, 0) < 0) return false;
        static const char* k = "0123456789abcdef";
        hex.clear();
        for (UCHAR c : d) { hex.push_back(k[c >> 4]); hex.push_back(k[c & 15]); }
        return true;
    }
private:
    BCRYPT_ALG_HANDLE alg_ = nullptr;
    BCRYPT_HASH_HANDLE h_ = nullptr;
    std::vector<UCHAR> obj_;
    bool ok_ = false;
};
}  // namespace

bool Sha256Buffer(const void* data, size_t len, std::string& hexOut) {
    Sha256Ctx c;
    return c.Update(data, len) && c.Final(hexOut);
}

bool Sha256File(const std::wstring& path, std::string& hexOut, std::string& err) {
    UniqueHandle f(CreateFileW(path.c_str(), GENERIC_READ,
                               FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                               nullptr, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, nullptr));
    if (!f.valid()) { err = "Không mở được file (mã lỗi " + std::to_string(GetLastError()) + ")"; return false; }
    Sha256Ctx c;
    std::vector<unsigned char> buf(1 << 20);
    for (;;) {
        if (g_cancel) { err = "Đã hủy"; return false; }
        DWORD got = 0;
        if (!ReadFile(f.get(), buf.data(), (DWORD)buf.size(), &got, nullptr)) {
            err = "Lỗi đọc (mã lỗi " + std::to_string(GetLastError()) + ")"; return false;
        }
        if (got == 0) break;
        if (!c.Update(buf.data(), got)) { err = "Lỗi băm"; return false; }
    }
    if (!c.Final(hexOut)) { err = "Không hoàn tất được SHA-256"; return false; }
    return true;
}

// ---- Authenticode (chi chu ky nhung trong file; file ky bang catalog co the bi bao Unsigned) ----
SigState CheckSignature(const std::wstring& path) {
    WINTRUST_FILE_INFO fi{};
    fi.cbStruct = sizeof fi;
    fi.pcwszFilePath = path.c_str();
    WINTRUST_DATA wd{};
    wd.cbStruct = sizeof wd;
    wd.dwUIChoice = WTD_UI_NONE;
    wd.fdwRevocationChecks = WTD_REVOKE_NONE;
    wd.dwUnionChoice = WTD_CHOICE_FILE;
    wd.pFile = &fi;
    wd.dwStateAction = WTD_STATEACTION_VERIFY;
    wd.dwProvFlags = 0x00001000 /*WTD_CACHE_ONLY_URL_RETRIEVAL*/ | 0x00000010 /*WTD_REVOCATION_CHECK_NONE*/;
    GUID action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
    LONG r = WinVerifyTrust((HWND)INVALID_HANDLE_VALUE, &action, &wd);
    wd.dwStateAction = WTD_STATEACTION_CLOSE;
    WinVerifyTrust((HWND)INVALID_HANDLE_VALUE, &action, &wd);
    if (r == 0) return SigState::Signed;
    if (r == (LONG)0x800B0100L || r == (LONG)0x800B0003L || r == (LONG)0x800B0001L) return SigState::Unsigned;
    if (r == (LONG)0x80096010L) return SigState::Invalid;  // TRUST_E_BAD_DIGEST
    return SigState::Unknown;
}

const char* SigName(SigState s) {
    switch (s) {
        case SigState::Signed: return "Signed";
        case SigState::Unsigned: return "Unsigned";
        case SigState::Invalid: return "Invalid";
        default: return "Unknown";
    }
}

}  // namespace dss

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include "CommandParser.h"
#include "QuarantineManager.h"
#include "ScannerCore.h"

using namespace dss;

namespace {

BOOL WINAPI CtrlHandler(DWORD type) {
    if (type == CTRL_C_EVENT || type == CTRL_BREAK_EVENT || type == CTRL_CLOSE_EVENT) {
        g_cancel = true;
        return TRUE;
    }
    return FALSE;
}

void PrintHelp() {
    std::puts(
        "DeepSystemScanner - công cụ quét và rà soát file (console)\n\n"
        "Cách dùng: DeepSystemScanner [tùy chọn]\n"
        "  --path <thư mục|ổ đĩa>  Quét vị trí này (dùng được nhiều lần). Mặc định: mọi ổ cố định/removable\n"
        "  --max-mb <N>            Bỏ qua file lớn hơn N MB (mặc định 200)\n"
        "  --no-defender           Không gọi Microsoft Defender\n"
        "  --verbose               Log từng file đang kiểm tra\n"
        "  --help                  Hiện trợ giúp");
}

bool Ask(const char* prompt) {
    std::printf("%s [y/N]: ", prompt);
    std::fflush(stdout);
    std::string s;
    if (!std::getline(std::cin, s)) return false;
    return s == "y" || s == "Y";
}

void ShowList(const std::vector<Detection>& dets) {
    std::puts("\n===== REVIEW DETECTED FILES =====\n");
    for (const auto& d : dets) {
        std::printf("[%d] %s\n    Trạng thái: %s\n    Nguồn: %s\n    Xử lý: %s\n    Khuyến nghị: %s\n\n",
                    d.id, ToUtf8(d.path).c_str(),
                    d.verdict == Verdict::ConfirmedThreat ? "Đã xác nhận độc hại" : "Đáng ngờ",
                    d.source.c_str(), StatusName(d.status),
                    d.verdict == Verdict::ConfirmedThreat ? "Cách ly" : "Kiểm tra thêm");
    }
    std::puts("Hành động: Q <ds> cách ly | D <ds> xóa | S <ds> bỏ qua | V <số> xem chi tiết | R <ds> khôi phục | L danh sách | 0 thoát\n");
}

void ShowDetail(const Detection& d) {
    std::printf("\n--- Chi tiết #%d ---\nĐường dẫn: %s\nLoại: %s\nKích thước: %llu byte\nSHA-256: %s\nNguồn: %s\nTrạng thái: %s\n",
                d.id, ToUtf8(d.path).c_str(), VerdictName(d.verdict), (unsigned long long)d.size,
                d.sha256.empty() ? "(chưa tính)" : d.sha256.c_str(), d.source.c_str(), StatusName(d.status));
    for (const auto& r : d.reasons) std::printf("Lý do: %s\n", r.c_str());
    std::puts("");
}

void ReviewMenu(std::vector<Detection>& dets, QuarantineManager& qm, ScanLogger& log) {
    if (dets.empty()) { log.Log("INFO", "Không có file nào cần xem xét."); return; }
    ShowList(dets);
    int maxId = (int)dets.size();
    for (;;) {
        std::printf("> ");
        std::fflush(stdout);
        std::string line;
        if (!std::getline(std::cin, line)) return;
        Command cmd; std::string err;
        if (!ParseCommand(line, maxId, cmd, err)) { std::printf("Lỗi: %s\n", err.c_str()); continue; }
        if (cmd.op == '0') { log.Log("INFO", "Kết thúc, không thay đổi thêm file nào."); return; }
        if (cmd.op == 'L') { ShowList(dets); continue; }
        for (int id : cmd.ids) {
            Detection& d = dets[(size_t)id - 1];  // id noi bo da duoc kiem tra 1..maxId
            std::string msg;
            switch (cmd.op) {
                case 'V': ShowDetail(d); break;
                case 'S': d.status = Status::Skipped; log.Log("ACTION", "Bỏ qua #" + std::to_string(id)); break;
                case 'Q': {
                    ShowDetail(d);
                    if (!Ask("Cách ly file này?")) break;
                    bool ok = qm.Quarantine(d, msg);
                    log.Log(ok ? "ACTION" : "ERROR", "Cách ly #" + std::to_string(id) + ": " + msg);
                    break;
                }
                case 'R': {
                    bool ok = qm.Restore(d, msg);
                    log.Log(ok ? "ACTION" : "ERROR", "Khôi phục #" + std::to_string(id) + ": " + msg);
                    break;
                }
                case 'D': {
                    ShowDetail(d);
                    std::puts("CẢNH BÁO: xóa vĩnh viễn, KHÔNG thể khôi phục. Nên ưu tiên cách ly (Q).");
                    if (!Ask("Xác nhận lần 1: xóa file này?")) break;
                    std::printf("Xác nhận lần 2: gõ DELETE để xóa: ");
                    std::string c; std::getline(std::cin, c);
                    if (c != "DELETE") { std::puts("Đã hủy."); break; }
                    bool ok = qm.DeletePermanently(d, msg);
                    log.Log(ok ? "ACTION" : "ERROR", "Xóa #" + std::to_string(id) + ": " + msg);
                    break;
                }
            }
        }
    }
}

}  // namespace

int main(int argc, char** argv) {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCtrlHandler(CtrlHandler, TRUE);

    ScanOptions opt;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--help" || a == "-h") { PrintHelp(); return 0; }
        else if (a == "--path" && i + 1 < argc) opt.roots.push_back(FromUtf8(argv[++i]));
        else if (a == "--max-mb" && i + 1 < argc) {
            long mb = std::atol(argv[++i]);
            if (mb < 1 || mb > 100000) { std::puts("--max-mb không hợp lệ"); return 2; }
            opt.maxFileSize = (uint64_t)mb * 1024 * 1024;
        }
        else if (a == "--no-defender") opt.useDefender = false;
        else if (a == "--verbose") opt.verbose = true;
        else { std::printf("Tham số không hợp lệ: %s\n", a.c_str()); PrintHelp(); return 2; }
    }
    if (opt.roots.empty()) opt.roots = DiskScanner::EnumerateRoots();

    std::wstring base = GetEnvW(L"LOCALAPPDATA");
    if (base.empty()) base = L".";
    base += L"\\DeepSystemScanner";
    ScanLogger log(base + L"\\logs");
    QuarantineManager qm(base + L"\\Quarantine");
    log.Log("INFO", "Log file: " + ToUtf8(log.LogPath()));

    ScannerCore core(log, opt);
    core.Run();
    g_cancel = false;  // cho phep menu/ham xac minh hoat dong sau khi huy quet
    ReviewMenu(core.Detections(), qm, log);
    return 0;
}

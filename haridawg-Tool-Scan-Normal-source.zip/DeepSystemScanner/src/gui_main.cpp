// haridawg Tool Scan Normal - giao dien Win32 thuan (GDI), hieu ung "mua ky tu" o nen.
#include "Util.h"
#include <commctrl.h>
#include <shlobj.h>
#include <cwchar>
#include <memory>
#include <random>
#include <thread>
#include <vector>
#include "QuarantineManager.h"
#include "ScannerCore.h"

using namespace dss;

namespace {

const wchar_t* kTitle = L"haridawg Tool Scan Normal";
enum { IDC_PATH = 101, IDC_BROWSE, IDC_DEFENDER, IDC_SCAN, IDC_CANCEL, IDC_LIST,
       IDC_Q, IDC_R, IDC_D, IDC_S, IDC_V, IDC_ALL, IDC_LOG };
const UINT WM_APP_LOG = WM_APP + 1, WM_APP_DET = WM_APP + 2, WM_APP_DONE = WM_APP + 3;
const UINT_PTR TIMER_RAIN = 1;
const COLORREF NEON = RGB(0, 255, 140), DARKBG = RGB(6, 16, 12);

// ---------- Hieu ung mua ky tu ----------
struct Rain {
    static const int CW = 14, CH = 16;
    int w = 0, h = 0, cols = 0, rows = 0;
    HDC dc = nullptr, cdc = nullptr, bdc = nullptr;
    HBITMAP bmp = nullptr, cbmp = nullptr, bbmp = nullptr;
    HGDIOBJ o1 = nullptr, o2 = nullptr, o3 = nullptr;
    HFONT font = nullptr;
    std::vector<int> row, delay, speed;
    std::vector<wchar_t> last;
    std::mt19937 rng{std::random_device{}()};

    void Free() {
        if (dc) { SelectObject(dc, o1); DeleteDC(dc); DeleteObject(bmp); }
        if (cdc) { SelectObject(cdc, o2); DeleteDC(cdc); DeleteObject(cbmp); }
        if (bdc) { SelectObject(bdc, o3); DeleteDC(bdc); DeleteObject(bbmp); }
        dc = cdc = bdc = nullptr;
    }
    void Init(HWND hwnd, int W, int H) {
        Free();
        if (W < 1 || H < 1) return;
        w = W; h = H;
        HDC scr = GetDC(hwnd);
        dc = CreateCompatibleDC(scr);  bmp = CreateCompatibleBitmap(scr, W, H);   o1 = SelectObject(dc, bmp);
        cdc = CreateCompatibleDC(scr); cbmp = CreateCompatibleBitmap(scr, W, H);  o2 = SelectObject(cdc, cbmp);
        bdc = CreateCompatibleDC(scr); bbmp = CreateCompatibleBitmap(scr, 1, 1);  o3 = SelectObject(bdc, bbmp);
        ReleaseDC(hwnd, scr);
        PatBlt(dc, 0, 0, W, H, BLACKNESS);
        PatBlt(bdc, 0, 0, 1, 1, BLACKNESS);
        if (!font)
            font = CreateFontW(-CH + 2, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                               CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FIXED_PITCH, L"MS Gothic");
        cols = W / CW + 1; rows = H / CH + 1;
        row.assign(cols, 0); delay.assign(cols, 0); speed.assign(cols, 1); last.assign(cols, L' ');
        for (int i = 0; i < cols; ++i) { row[i] = -(int)(rng() % (rows * 2)); speed[i] = 1 + rng() % 3; }
    }
    wchar_t RandCh() {
        unsigned r = rng() % 10;
        if (r < 5) return (wchar_t)(0xFF66 + rng() % (0xFF9D - 0xFF66 + 1));  // katakana ban rong
        if (r < 8) return (wchar_t)(L'0' + rng() % 10);
        static const wchar_t sym[] = L"ABCDEFGHIJKLMNOPQRSTUVWXYZ:.=*+-<>|";
        return sym[rng() % (sizeof(sym) / sizeof(wchar_t) - 1)];
    }
    void Step() {
        if (!dc) return;
        BLENDFUNCTION bf{AC_SRC_OVER, 0, 38, 0};
        AlphaBlend(dc, 0, 0, w, h, bdc, 0, 0, 1, 1, bf);  // mo dan -> tao vet mua
        HGDIOBJ of = SelectObject(dc, font);
        SetBkMode(dc, TRANSPARENT);
        for (int i = 0; i < cols; ++i) {
            if (++delay[i] < speed[i]) continue;
            delay[i] = 0;
            int x = i * CW;
            if (row[i] >= 0 && row[i] < rows) {
                SetTextColor(dc, RGB(0, 170, 70));
                TextOutW(dc, x, row[i] * CH, &last[i], 1);
            }
            ++row[i];
            if (row[i] >= 0 && row[i] < rows) {
                last[i] = RandCh();
                SetTextColor(dc, RGB(210, 255, 225));
                TextOutW(dc, x, row[i] * CH, &last[i], 1);
            } else if (row[i] >= rows + (int)(rng() % 25)) {
                row[i] = -(int)(rng() % (rows / 2 + 1));
                speed[i] = 1 + rng() % 3;
            }
        }
        SelectObject(dc, of);
    }
};

// ---------- Trang thai ung dung ----------
struct App {
    HWND hwnd = nullptr, path = nullptr, browse = nullptr, defender = nullptr, scan = nullptr, cancel = nullptr,
         list = nullptr, bq = nullptr, br = nullptr, bd = nullptr, bs = nullptr, bv = nullptr, ball = nullptr, log = nullptr;
    HFONT ui = nullptr, mono = nullptr, title = nullptr, sub = nullptr;
    HBRUSH darkBrush = nullptr;
    HICON icon = nullptr;
    HINSTANCE inst = nullptr;
    Rain rain;
    bool useDefender = true, running = false, allChecked = false;
    int W = 0, H = 0;
    RECT lblRc{}, statusRc{};
    std::wstring status = L"Sẵn sàng.";
    std::vector<Detection> dets;
    std::unique_ptr<ScanLogger> logger;
    std::unique_ptr<QuarantineManager> qm;
    std::unique_ptr<ScannerCore> core;
    std::thread worker;
} g;

std::wstring W(const std::string& s) { return FromUtf8(s); }

HWND MakeBtn(int id, const wchar_t* text) {
    HWND b = CreateWindowExW(0, L"BUTTON", text, WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_OWNERDRAW,
                             0, 0, 10, 10, g.hwnd, (HMENU)(INT_PTR)id, g.inst, nullptr);
    SendMessageW(b, WM_SETFONT, (WPARAM)g.ui, TRUE);
    return b;
}

void AppendLog(const std::string& utf8) {
    std::wstring w = W(utf8), o;
    for (wchar_t c : w) { if (c == L'\n') o += L'\r'; o += c; }
    int len = GetWindowTextLengthW(g.log);
    if (len > 300000) { SendMessageW(g.log, EM_SETSEL, 0, 100000); SendMessageW(g.log, EM_REPLACESEL, FALSE, (LPARAM)L""); len = GetWindowTextLengthW(g.log); }
    SendMessageW(g.log, EM_SETSEL, len, len);
    SendMessageW(g.log, EM_REPLACESEL, FALSE, (LPARAM)o.c_str());
}

void UpdateRow(int i) {
    std::wstring st = W(StatusName(g.dets[(size_t)i].status));
    ListView_SetItemText(g.list, i, 2, (LPWSTR)st.c_str());
}

void AddRow(const Detection& d) {
    int i = (int)g.dets.size() - 1;
    std::wstring id = std::to_wstring(d.id);
    LVITEMW it{}; it.mask = LVIF_TEXT; it.iItem = i; it.pszText = (LPWSTR)id.c_str();
    ListView_InsertItem(g.list, &it);
    std::wstring type = d.verdict == Verdict::ConfirmedThreat ? L"Đã xác nhận" : L"Đáng ngờ";
    ListView_SetItemText(g.list, i, 1, (LPWSTR)type.c_str());
    UpdateRow(i);
    ListView_SetItemText(g.list, i, 3, (LPWSTR)d.path.c_str());
    std::wstring src = W(d.source);
    ListView_SetItemText(g.list, i, 4, (LPWSTR)src.c_str());
}

std::vector<int> Targets() {
    std::vector<int> t;
    int n = ListView_GetItemCount(g.list);
    for (int i = 0; i < n; ++i) if (ListView_GetCheckState(g.list, i)) t.push_back(i);
    if (t.empty()) {
        int i = -1;
        while ((i = ListView_GetNextItem(g.list, i, LVNI_SELECTED)) >= 0) t.push_back(i);
    }
    return t;
}

void ShowDetail(int i) {
    if (i < 0 || i >= (int)g.dets.size()) return;
    const Detection& d = g.dets[(size_t)i];
    std::wstring t = L"Đường dẫn: " + d.path + L"\nLoại: " + W(VerdictName(d.verdict)) +
                     L"\nKích thước: " + std::to_wstring(d.size) + L" byte\nSHA-256: " +
                     (d.sha256.empty() ? L"(chưa tính)" : W(d.sha256)) + L"\nNguồn: " + W(d.source) +
                     L"\nTrạng thái: " + W(StatusName(d.status)) + L"\n";
    for (const auto& r : d.reasons) t += L"\n• " + W(r);
    MessageBoxW(g.hwnd, t.c_str(), kTitle, MB_OK | MB_ICONINFORMATION);
}

void DoAction(char op) {
    std::vector<int> t = Targets();
    if (t.empty()) {
        MessageBoxW(g.hwnd, L"Hãy tích chọn (hoặc bấm chọn) ít nhất một file trong danh sách.", kTitle, MB_ICONINFORMATION);
        return;
    }
    if (op == 'V') { ShowDetail(t[0]); return; }
    std::wstring n = std::to_wstring(t.size());
    if (op == 'Q' && MessageBoxW(g.hwnd, (L"Cách ly " + n + L" file đã chọn?\nFile được chuyển vào khu cách ly và có thể khôi phục.").c_str(),
                                 kTitle, MB_YESNO | MB_ICONQUESTION) != IDYES) return;
    if (op == 'D') {
        if (MessageBoxW(g.hwnd, (L"Xóa " + n + L" file đã chọn?").c_str(), kTitle, MB_YESNO | MB_ICONWARNING) != IDYES) return;
        if (MessageBoxW(g.hwnd, L"XÁC NHẬN LẦN 2: xóa vĩnh viễn, KHÔNG thể khôi phục.\nNên dùng Cách ly thay vì xóa. Tiếp tục xóa?",
                        kTitle, MB_YESNO | MB_ICONSTOP | MB_DEFBUTTON2) != IDYES) return;
    }
    for (int i : t) {
        if (i < 0 || i >= (int)g.dets.size()) continue;
        Detection& d = g.dets[(size_t)i];
        std::string msg; bool ok = true;
        const char* what = "";
        if (op == 'Q') { ok = g.qm->Quarantine(d, msg); what = "Cách ly"; }
        else if (op == 'R') { ok = g.qm->Restore(d, msg); what = "Khôi phục"; }
        else if (op == 'D') { ok = g.qm->DeletePermanently(d, msg); what = "Xóa"; }
        else if (op == 'S') { d.status = Status::Skipped; msg = "Bỏ qua"; what = "Bỏ qua"; }
        g.logger->Log(ok ? "ACTION" : "ERROR", std::string(what) + " #" + std::to_string(d.id) + ": " + msg);
        UpdateRow(i);
    }
}

void SetRunning(bool r) {
    g.running = r;
    EnableWindow(g.scan, !r);
    EnableWindow(g.cancel, r);
    EnableWindow(g.path, !r);
    EnableWindow(g.browse, !r);
    InvalidateRect(g.scan, nullptr, FALSE);
    InvalidateRect(g.cancel, nullptr, FALSE);
}

void StartScan() {
    if (g.running) return;
    wchar_t buf[2048]; GetWindowTextW(g.path, buf, 2048);
    std::wstring p = buf;
    while (!p.empty() && (p.back() == L' ' || (p.back() == L'\\' && p.size() > 3))) p.pop_back();
    while (!p.empty() && p.front() == L' ') p.erase(p.begin());
    ScanOptions opt;
    if (p.empty()) {
        if (MessageBoxW(g.hwnd, L"Chưa nhập thư mục. Quét TOÀN BỘ ổ đĩa? (có thể rất lâu)", kTitle, MB_YESNO | MB_ICONQUESTION) != IDYES) return;
        opt.roots = DiskScanner::EnumerateRoots();
    } else {
        DWORD a = GetFileAttributesW(p.c_str());
        if (a == INVALID_FILE_ATTRIBUTES || !(a & FILE_ATTRIBUTE_DIRECTORY)) {
            MessageBoxW(g.hwnd, L"Đường dẫn không tồn tại hoặc không phải thư mục.", kTitle, MB_ICONWARNING);
            return;
        }
        opt.roots.push_back(p);
    }
    opt.useDefender = g.useDefender;
    g.dets.clear();
    ListView_DeleteAllItems(g.list);
    SetWindowTextW(g.log, L"");
    g_cancel = false;
    g.core = std::make_unique<ScannerCore>(*g.logger, opt);
    HWND hw = g.hwnd;
    g.core->onDetection = [hw](const Detection& d) { PostMessageW(hw, WM_APP_DET, 0, (LPARAM) new Detection(d)); };
    g.status = L"Đang quét...";
    SetRunning(true);
    g.worker = std::thread([hw]() { g.core->Run(); PostMessageW(hw, WM_APP_DONE, 0, 0); });
}

void Layout() {
    const int M = 16;
    g.lblRc = {M, 98, g.W - M, 120};
    MoveWindow(g.path, M, 122, g.W - 2 * M - 108, 28, TRUE);
    MoveWindow(g.browse, g.W - M - 100, 122, 100, 28, TRUE);
    MoveWindow(g.defender, M, 158, 240, 32, TRUE);
    MoveWindow(g.scan, 264, 158, 130, 32, TRUE);
    MoveWindow(g.cancel, 402, 158, 110, 32, TRUE);
    g.statusRc = {524, 158, g.W - M, 190};
    int listTop = 202;
    int avail = g.H - listTop - 48 - M;
    int listH = avail > 260 ? avail * 55 / 100 : 130;
    MoveWindow(g.list, M, listTop, g.W - 2 * M, listH, TRUE);
    int ay = listTop + listH + 8;
    MoveWindow(g.bq, M, ay, 120, 32, TRUE);
    MoveWindow(g.br, M + 128, ay, 120, 32, TRUE);
    MoveWindow(g.bd, M + 256, ay, 150, 32, TRUE);
    MoveWindow(g.bs, M + 414, ay, 100, 32, TRUE);
    MoveWindow(g.bv, M + 522, ay, 100, 32, TRUE);
    MoveWindow(g.ball, g.W - M - 150, ay, 150, 32, TRUE);
    int logTop = ay + 40;
    MoveWindow(g.log, M, logTop, g.W - 2 * M, std::max(60, g.H - logTop - M), TRUE);
}

void Strip(HDC dc, int x, int y, int w, int h, BYTE a) {
    BLENDFUNCTION b{AC_SRC_OVER, 0, a, 0};
    AlphaBlend(dc, x, y, w, h, g.rain.bdc, 0, 0, 1, 1, b);
}

void DrawOverlay(HDC dc) {
    Strip(dc, 12, 8, g.W - 24, 84, 175);
    HPEN pen = CreatePen(PS_SOLID, 1, RGB(0, 200, 110));
    HGDIOBJ op = SelectObject(dc, pen), ob = SelectObject(dc, GetStockObject(NULL_BRUSH));
    Rectangle(dc, 12, 8, g.W - 12, 92);
    SelectObject(dc, op); SelectObject(dc, ob); DeleteObject(pen);
    if (g.icon) DrawIconEx(dc, 26, 18, g.icon, 64, 64, 0, nullptr, DI_NORMAL);
    SetBkMode(dc, TRANSPARENT);
    HGDIOBJ of = SelectObject(dc, g.title);
    SetTextColor(dc, RGB(0, 110, 60)); TextOutW(dc, 105, 21, kTitle, (int)wcslen(kTitle));
    SetTextColor(dc, NEON);            TextOutW(dc, 104, 20, kTitle, (int)wcslen(kTitle));
    SelectObject(dc, g.sub);
    SetTextColor(dc, RGB(130, 225, 180));
    const wchar_t* s = L"Quét tệp đáng ngờ  •  Cách ly có thể khôi phục  •  Không tự xóa khi bạn chưa xác nhận";
    TextOutW(dc, 106, 62, s, (int)wcslen(s));
    Strip(dc, g.lblRc.left, g.lblRc.top, g.lblRc.right - g.lblRc.left, g.lblRc.bottom - g.lblRc.top, 170);
    const wchar_t* l = L"Thư mục cần quét (để trống = toàn bộ ổ đĩa):";
    SetTextColor(dc, NEON);
    TextOutW(dc, g.lblRc.left + 6, g.lblRc.top + 3, l, (int)wcslen(l));
    Strip(dc, g.statusRc.left, g.statusRc.top, g.statusRc.right - g.statusRc.left, g.statusRc.bottom - g.statusRc.top, 170);
    RECT r = g.statusRc; r.left += 8;
    SetTextColor(dc, RGB(190, 255, 220));
    DrawTextW(dc, g.status.c_str(), -1, &r, DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);
    SelectObject(dc, of);
}

void DrawButton(const DRAWITEMSTRUCT* di) {
    bool dis = di->itemState & ODS_DISABLED, sel = di->itemState & ODS_SELECTED;
    bool danger = di->CtlID == IDC_D;
    COLORREF edge = dis ? RGB(70, 90, 80) : (danger ? RGB(255, 80, 80) : RGB(0, 230, 130));
    HBRUSH br = CreateSolidBrush(sel ? RGB(0, 90, 50) : RGB(6, 26, 16));
    FillRect(di->hDC, &di->rcItem, br); DeleteObject(br);
    HPEN pen = CreatePen(PS_SOLID, 1, edge);
    HGDIOBJ op = SelectObject(di->hDC, pen), ob = SelectObject(di->hDC, GetStockObject(NULL_BRUSH));
    Rectangle(di->hDC, di->rcItem.left, di->rcItem.top, di->rcItem.right, di->rcItem.bottom);
    SelectObject(di->hDC, op); SelectObject(di->hDC, ob); DeleteObject(pen);
    wchar_t t[64]; GetWindowTextW(di->hwndItem, t, 64);
    SetBkMode(di->hDC, TRANSPARENT);
    HGDIOBJ of = SelectObject(di->hDC, g.ui);
    RECT r = di->rcItem;
    if (di->CtlID == IDC_DEFENDER) {  // checkbox tu ve
        RECT box{r.left + 6, r.top + 8, r.left + 22, r.top + 24};
        HPEN p2 = CreatePen(PS_SOLID, 1, RGB(0, 230, 130));
        HGDIOBJ o2 = SelectObject(di->hDC, p2);
        Rectangle(di->hDC, box.left, box.top, box.right, box.bottom);
        if (g.useDefender) {
            MoveToEx(di->hDC, box.left + 3, box.top + 8, nullptr); LineTo(di->hDC, box.left + 6, box.top + 12);
            LineTo(di->hDC, box.left + 13, box.top + 4);
        }
        SelectObject(di->hDC, o2); DeleteObject(p2);
        r.left += 30;
        SetTextColor(di->hDC, NEON);
        DrawTextW(di->hDC, t, -1, &r, DT_SINGLELINE | DT_VCENTER | DT_LEFT);
    } else {
        SetTextColor(di->hDC, dis ? RGB(110, 130, 120) : (danger ? RGB(255, 130, 130) : NEON));
        DrawTextW(di->hDC, t, -1, &r, DT_SINGLELINE | DT_VCENTER | DT_CENTER);
    }
    SelectObject(di->hDC, of);
}

void Browse() {
    BROWSEINFOW bi{};
    bi.hwndOwner = g.hwnd;
    bi.lpszTitle = L"Chọn thư mục cần quét";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    LPITEMIDLIST pidl = SHBrowseForFolderW(&bi);
    if (!pidl) return;
    wchar_t p[MAX_PATH];
    if (SHGetPathFromIDListW(pidl, p)) SetWindowTextW(g.path, p);
    CoTaskMemFree(pidl);
}

LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case WM_CREATE: {
        g.hwnd = h;
        g.ui = CreateFontW(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
        g.mono = CreateFontW(-14, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, FIXED_PITCH, L"Consolas");
        g.title = CreateFontW(-34, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
        g.sub = CreateFontW(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
        g.darkBrush = CreateSolidBrush(DARKBG);
        g.icon = (HICON)LoadImageW(g.inst, MAKEINTRESOURCEW(1), IMAGE_ICON, 64, 64, 0);
        g.path = CreateWindowExW(0, L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL | WS_TABSTOP,
                                 0, 0, 10, 10, h, (HMENU)IDC_PATH, g.inst, nullptr);
        SendMessageW(g.path, WM_SETFONT, (WPARAM)g.ui, TRUE);
        g.browse = MakeBtn(IDC_BROWSE, L"Duyệt...");
        g.defender = MakeBtn(IDC_DEFENDER, L"Dùng Microsoft Defender");
        g.scan = MakeBtn(IDC_SCAN, L"▶  Bắt đầu quét");
        g.cancel = MakeBtn(IDC_CANCEL, L"■  Dừng");
        EnableWindow(g.cancel, FALSE);
        g.list = CreateWindowExW(0, WC_LISTVIEWW, L"", WS_CHILD | WS_VISIBLE | WS_BORDER | LVS_REPORT | LVS_SHOWSELALWAYS | WS_TABSTOP,
                                 0, 0, 10, 10, h, (HMENU)IDC_LIST, g.inst, nullptr);
        ListView_SetExtendedListViewStyle(g.list, LVS_EX_FULLROWSELECT | LVS_EX_CHECKBOXES | LVS_EX_DOUBLEBUFFER | LVS_EX_GRIDLINES);
        ListView_SetBkColor(g.list, DARKBG);
        ListView_SetTextBkColor(g.list, DARKBG);
        ListView_SetTextColor(g.list, NEON);
        SendMessageW(g.list, WM_SETFONT, (WPARAM)g.ui, TRUE);
        const wchar_t* cols[] = {L"#", L"Loại", L"Trạng thái", L"Đường dẫn", L"Nguồn"};
        int widths[] = {44, 110, 150, 520, 220};
        for (int i = 0; i < 5; ++i) {
            LVCOLUMNW c{}; c.mask = LVCF_TEXT | LVCF_WIDTH; c.pszText = (LPWSTR)cols[i]; c.cx = widths[i];
            ListView_InsertColumn(g.list, i, &c);
        }
        g.bq = MakeBtn(IDC_Q, L"Cách ly");
        g.br = MakeBtn(IDC_R, L"Khôi phục");
        g.bd = MakeBtn(IDC_D, L"Xóa vĩnh viễn");
        g.bs = MakeBtn(IDC_S, L"Bỏ qua");
        g.bv = MakeBtn(IDC_V, L"Chi tiết");
        g.ball = MakeBtn(IDC_ALL, L"Chọn / bỏ tất cả");
        g.log = CreateWindowExW(0, L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
                                0, 0, 10, 10, h, (HMENU)IDC_LOG, g.inst, nullptr);
        SendMessageW(g.log, WM_SETFONT, (WPARAM)g.mono, TRUE);
        SendMessageW(g.log, EM_SETLIMITTEXT, 0x7FFFFFFE, 0);

        std::wstring base = GetEnvW(L"LOCALAPPDATA");
        if (base.empty()) base = L".";
        base += L"\\haridawgToolScanNormal";
        g.logger = std::make_unique<ScanLogger>(base + L"\\logs");
        g.qm = std::make_unique<QuarantineManager>(base + L"\\Quarantine");
        HWND hw = h;
        g.logger->SetSink([hw](const std::string& s) { PostMessageW(hw, WM_APP_LOG, 0, (LPARAM) new std::string(s)); });
        SetTimer(h, TIMER_RAIN, 40, nullptr);
        return 0;
    }
    case WM_SIZE: {
        RECT rc; GetClientRect(h, &rc);
        g.W = rc.right; g.H = rc.bottom;
        if (g.W > 0 && g.H > 0 && g.path) { g.rain.Init(h, g.W, g.H); Layout(); }
        return 0;
    }
    case WM_GETMINMAXINFO: {
        MINMAXINFO* mi = (MINMAXINFO*)lp; mi->ptMinTrackSize.x = 860; mi->ptMinTrackSize.y = 620; return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC hdc = BeginPaint(h, &ps);
        if (g.rain.dc) {
            BitBlt(g.rain.cdc, 0, 0, g.rain.w, g.rain.h, g.rain.dc, 0, 0, SRCCOPY);
            DrawOverlay(g.rain.cdc);
            BitBlt(hdc, 0, 0, g.rain.w, g.rain.h, g.rain.cdc, 0, 0, SRCCOPY);
        }
        EndPaint(h, &ps);
        return 0;
    }
    case WM_TIMER: {
        if (wp != TIMER_RAIN) break;
        g.rain.Step();
        static int n = 0;
        if (g.running && g.core && ++n % 10 == 0)
            g.status = L"Đang quét...  Đã duyệt " + std::to_wstring(g.core->Stats().filesSeen.load()) +
                       L" file  |  Phát hiện: " + std::to_wstring(g.dets.size());
        InvalidateRect(h, nullptr, FALSE);
        return 0;
    }
    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wp;
        SetTextColor(dc, RGB(0, 230, 120)); SetBkColor(dc, DARKBG);
        return (LRESULT)g.darkBrush;
    }
    case WM_DRAWITEM: DrawButton((DRAWITEMSTRUCT*)lp); return TRUE;
    case WM_COMMAND: {
        if (HIWORD(wp) != BN_CLICKED) break;
        switch (LOWORD(wp)) {
        case IDC_BROWSE: Browse(); break;
        case IDC_DEFENDER: g.useDefender = !g.useDefender; InvalidateRect(g.defender, nullptr, FALSE); break;
        case IDC_SCAN: StartScan(); break;
        case IDC_CANCEL: g_cancel = true; g.status = L"Đang hủy..."; break;
        case IDC_Q: DoAction('Q'); break;
        case IDC_R: DoAction('R'); break;
        case IDC_D: DoAction('D'); break;
        case IDC_S: DoAction('S'); break;
        case IDC_V: DoAction('V'); break;
        case IDC_ALL: {
            g.allChecked = !g.allChecked;
            int n = ListView_GetItemCount(g.list);
            for (int i = 0; i < n; ++i) ListView_SetCheckState(g.list, i, g.allChecked);
            break;
        }
        }
        return 0;
    }
    case WM_NOTIFY: {
        NMHDR* nh = (NMHDR*)lp;
        if (nh->idFrom == IDC_LIST) {
            if (nh->code == NM_CUSTOMDRAW) {
                NMLVCUSTOMDRAW* cd = (NMLVCUSTOMDRAW*)lp;
                if (cd->nmcd.dwDrawStage == CDDS_PREPAINT) return CDRF_NOTIFYITEMDRAW;
                if (cd->nmcd.dwDrawStage == CDDS_ITEMPREPAINT) {
                    size_t i = (size_t)cd->nmcd.dwItemSpec;
                    if (i < g.dets.size())
                        cd->clrText = g.dets[i].verdict == Verdict::ConfirmedThreat ? RGB(255, 100, 100) : RGB(255, 210, 80);
                    cd->clrTextBk = DARKBG;
                    return CDRF_NEWFONT;
                }
            } else if (nh->code == NM_DBLCLK) {
                ShowDetail(((NMITEMACTIVATE*)lp)->iItem);
            }
        }
        break;
    }
    case WM_APP_LOG: { std::unique_ptr<std::string> s((std::string*)lp); AppendLog(*s); return 0; }
    case WM_APP_DET: {
        std::unique_ptr<Detection> d((Detection*)lp);
        g.dets.push_back(*d);
        AddRow(g.dets.back());
        return 0;
    }
    case WM_APP_DONE: {
        if (g.worker.joinable()) g.worker.join();
        const ScanStats& s = g.core->Stats();
        g.status = std::wstring(s.cancelled ? L"Đã hủy (chưa đầy đủ). " : L"Quét xong. ") + L"Duyệt " +
                   std::to_wstring(s.filesSeen.load()) + L" file, phát hiện " + std::to_wstring(g.dets.size()) +
                   L", từ chối truy cập " + std::to_wstring(s.accessDenied.load());
        g_cancel = false;
        SetRunning(false);
        return 0;
    }
    case WM_DESTROY:
        KillTimer(h, TIMER_RAIN);
        g_cancel = true;
        if (g.worker.joinable()) g.worker.join();
        g.rain.Free();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, m, wp, lp);
}

}  // namespace

int WINAPI WinMain(HINSTANCE inst, HINSTANCE, LPSTR, int show) {
    g.inst = inst;
    OleInitialize(nullptr);
    INITCOMMONCONTROLSEX ic{sizeof ic, ICC_LISTVIEW_CLASSES};
    InitCommonControlsEx(&ic);
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof wc;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
    wc.hIconSm = wc.hIcon;
    wc.lpszClassName = L"HaridawgToolScanNormal";
    RegisterClassExW(&wc);
    HWND h = CreateWindowExW(0, wc.lpszClassName, kTitle, WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                             CW_USEDEFAULT, CW_USEDEFAULT, 1060, 760, nullptr, nullptr, inst, nullptr);
    if (!h) return 1;
    ShowWindow(h, show);
    UpdateWindow(h);
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    OleUninitialize();
    return (int)msg.wParam;
}

#include "DiskScanner.h"

namespace dss {

std::vector<std::wstring> DiskScanner::EnumerateRoots() {
    std::vector<std::wstring> roots;
    DWORD mask = GetLogicalDrives();
    for (int i = 0; i < 26; ++i) {
        if (!(mask & (1u << i))) continue;
        std::wstring r = std::wstring(1, (wchar_t)(L'A' + i)) + L":\\";
        UINT t = GetDriveTypeW(r.c_str());
        if (t == DRIVE_FIXED || t == DRIVE_REMOVABLE) roots.push_back(r);
    }
    return roots;
}

void DiskScanner::Walk(const std::wstring& rootIn, const Callbacks& cb) const {
    std::wstring root = rootIn;
    while (root.size() > 2 && root.back() == L'\\') root.pop_back();
    std::vector<std::wstring> stack{root};
    while (!stack.empty() && !g_cancel) {
        std::wstring dir = std::move(stack.back());
        stack.pop_back();
        std::wstring pattern = dir + L"\\*";
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileExW(pattern.c_str(), FindExInfoBasic, &fd, FindExSearchNameMatch,
                                    nullptr, FIND_FIRST_EX_LARGE_FETCH);
        if (h == INVALID_HANDLE_VALUE && GetLastError() == ERROR_INVALID_PARAMETER) {
            // Du phong cho he thong khong ho tro FindExInfoBasic / LARGE_FETCH
            h = FindFirstFileExW(pattern.c_str(), FindExInfoStandard, &fd, FindExSearchNameMatch, nullptr, 0);
        }
        if (h == INVALID_HANDLE_VALUE) {
            if (cb.onError) cb.onError(dir, GetLastError());
            continue;
        }
        do {
            if (g_cancel) break;
            const wchar_t* n = fd.cFileName;
            if (n[0] == L'.' && (n[1] == 0 || (n[1] == L'.' && n[2] == 0))) continue;
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) continue;
            std::wstring full = dir + L"\\" + n;
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                if (full.size() >= MAX_PATH - 4) { if (cb.onError) cb.onError(full, ERROR_FILENAME_EXCED_RANGE); continue; }
                stack.push_back(std::move(full));
            } else {
                if (full.size() >= MAX_PATH) { if (cb.onError) cb.onError(full, ERROR_FILENAME_EXCED_RANGE); continue; }
                FileInfo fi;
                fi.path = std::move(full);
                fi.size = ((uint64_t)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
                fi.attrs = fd.dwFileAttributes;
                if (cb.onFile) cb.onFile(fi);
            }
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
}

}  // namespace dss

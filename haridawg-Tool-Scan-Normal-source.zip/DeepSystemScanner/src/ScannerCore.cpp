#include "ScannerCore.h"

namespace dss {

void ScannerCore::Run() {
    log_.Log("INFO", "Bắt đầu quét. Nhấn Ctrl+C để hủy có kiểm soát.");
    if (opt_.useDefender) {
        def_ = DefenderIntegration::Detect();
        if (def_.available) log_.Log("INFO", "Microsoft Defender khả dụng: " + ToUtf8(def_.mpCmdRun));
        else log_.Log("UNSUPPORTED", "Defender không khả dụng (" + def_.note +
                      "). Kết quả chỉ dựa vào heuristic, không có xác nhận từ bộ máy AV.");
    } else {
        log_.Log("WARN", "Đã tắt Defender theo tùy chọn. Chỉ có heuristic.");
    }

    DiskScanner ds;
    DiskScanner::Callbacks cb;
    cb.onFile = [this](const FileInfo& fi) { HandleFile(fi); };
    cb.onError = [this](const std::wstring& p, DWORD e) {
        if (e == ERROR_ACCESS_DENIED || e == ERROR_SHARING_VIOLATION) {
            ++stats_.accessDenied;
            if (opt_.verbose) log_.Log(VerdictName(Verdict::AccessDenied), ToUtf8(p));
        } else {
            ++stats_.errors;
            log_.Log(VerdictName(Verdict::ScanError), ToUtf8(p) + " (mã lỗi " + std::to_string(e) + ")");
        }
    };
    for (const auto& root : opt_.roots) {
        if (g_cancel) break;
        log_.Log("SCAN", "Đang quét: " + ToUtf8(root));
        ds.Walk(root, cb);
    }
    stats_.cancelled = g_cancel.load();

    log_.Log("INFO", std::string(stats_.cancelled ? "QUÉT BỊ HỦY (chưa đầy đủ). " : "Quét xong. ") +
        "File thấy: " + std::to_string(stats_.filesSeen.load()) + ", đã phân tích: " + std::to_string(stats_.analyzed.load()) +
        ", bỏ qua: " + std::to_string(stats_.skipped.load()) + ", bị từ chối truy cập: " + std::to_string(stats_.accessDenied.load()) +
        ", lỗi: " + std::to_string(stats_.errors.load()) + ", phát hiện: " + std::to_string(dets_.size()));
    log_.Log("INFO", "Lưu ý: không phát hiện gì KHÔNG đồng nghĩa với an toàn tuyệt đối. Vùng bị từ chối/bỏ qua chưa được kiểm tra.");
}

void ScannerCore::HandleFile(const FileInfo& fi) {
    ++stats_.filesSeen;
    if (stats_.filesSeen % 5000 == 0) log_.Log("INFO", "Tiến độ: " + std::to_string(stats_.filesSeen.load()) + " file đã duyệt");
    AnalysisResult r = analyzer_.Analyze(fi, opt_.maxFileSize);
    if (!r.relevant) return;
    if (opt_.verbose) {
        log_.Log("SCAN", "Đang kiểm tra: " + ToUtf8(fi.path));
        if (!r.sha256.empty()) log_.Log("INFO", "SHA256: " + r.sha256);
        for (const auto& n : r.notes) log_.Log("INFO", "Ghi chú yếu: " + n);
    }
    if (r.skipped) { ++stats_.skipped; return; }
    if (r.verdict == Verdict::AccessDenied) { ++stats_.accessDenied; log_.Log("ACCESS_DENIED", ToUtf8(fi.path) + " - " + r.error); return; }
    if (r.verdict == Verdict::ScanError) { ++stats_.errors; log_.Log("SCAN_ERROR", ToUtf8(fi.path) + " - " + r.error); return; }
    ++stats_.analyzed;
    if (!r.error.empty()) log_.Log("WARN", "Không tính được SHA-256: " + ToUtf8(fi.path) + " - " + r.error);

    if (r.verdict == Verdict::Suspicious && def_.available) {
        // Xin y kien thu hai tu Defender cho file bi heuristic gan co
        std::string detail;
        DefenderResult dr = DefenderIntegration::ScanFile(def_, fi.path, opt_.defenderTimeoutMs, detail);
        switch (dr) {
            case DefenderResult::ThreatFound:
                r.verdict = Verdict::ConfirmedThreat;
                r.source = "Microsoft Defender (MpCmdRun) + heuristic";
                r.reasons.push_back("Microsoft Defender báo phát hiện: " + detail);
                break;
            case DefenderResult::Clean:
                r.reasons.push_back("Defender không phát hiện (" + detail + "); chỉ còn cảnh báo heuristic");
                break;
            default:
                r.reasons.push_back("Không lấy được kết luận Defender: " + detail);
        }
    }
    if (r.verdict == Verdict::Suspicious || r.verdict == Verdict::ConfirmedThreat) AddDetection(fi, r);
}

void ScannerCore::AddDetection(const FileInfo& fi, AnalysisResult& r) {
    Detection d;
    d.id = (int)dets_.size() + 1;
    d.path = fi.path;
    d.sha256 = r.sha256;
    d.verdict = r.verdict;
    d.reasons = r.reasons;
    d.source = r.source;
    d.size = fi.size;
    dets_.push_back(d);
    log_.Log("DETECTION", std::string("Mức độ: ") + VerdictName(d.verdict) + " | " + ToUtf8(d.path));
    log_.LogDetection(dets_.back());
    if (onDetection) onDetection(dets_.back());
}

}  // namespace dss

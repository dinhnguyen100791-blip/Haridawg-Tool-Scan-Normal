#include "ThreatAnalyzer.h"
#include <algorithm>
#include <cstring>

namespace dss {
namespace {

const wchar_t* kExec[] = {L".exe", L".dll", L".sys", L".scr", L".msi", L".ocx", L".com"};
const wchar_t* kSigExt[] = {L".exe", L".dll", L".sys", L".scr", L".msi", L".ocx"};
const wchar_t* kScript[] = {L".ps1", L".bat", L".cmd", L".vbs", L".vbe", L".js", L".jse", L".wsf", L".hta"};
const wchar_t* kDecoy[] = {L".jpg", L".jpeg", L".png", L".gif", L".txt", L".pdf", L".doc", L".docx",
                           L".xls", L".xlsx", L".mp3", L".mp4", L".zip"};
const wchar_t* kDocExt[] = {L".pdf", L".doc", L".docx", L".xls", L".xlsx", L".jpg", L".jpeg", L".png",
                            L".txt", L".mp3", L".mp4", L".zip"};

template <size_t N>
bool In(const std::wstring& e, const wchar_t* (&arr)[N]) {
    for (auto s : arr) if (e == s) return true;
    return false;
}

std::wstring ExtOf(const std::wstring& name) {
    size_t d = name.find_last_of(L'.');
    return d == std::wstring::npos ? L"" : name.substr(d);
}

bool ReadHead(const std::wstring& path, size_t maxBytes, std::string& out, DWORD& err) {
    UniqueHandle h(CreateFileW(path.c_str(), GENERIC_READ,
                               FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                               nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (!h.valid()) { err = GetLastError(); return false; }
    out.assign(maxBytes, '\0');
    DWORD got = 0;
    if (!ReadFile(h.get(), &out[0], (DWORD)maxBytes, &got, nullptr)) { err = GetLastError(); return false; }
    out.resize(got);
    return true;
}

std::string Lower(std::string s) {
    for (char& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}

bool InUserWritable(const std::wstring& lp) {
    static const wchar_t* k[] = {L"\\temp\\", L"\\downloads\\", L"\\appdata\\roaming\\", L"\\$recycle.bin\\", L"\\users\\public\\"};
    for (auto s : k) if (lp.find(s) != std::wstring::npos) return true;
    return false;
}

}  // namespace

AnalysisResult ThreatAnalyzer::Analyze(const FileInfo& fi, uint64_t maxSize) const {
    AnalysisResult r;
    std::wstring lp = ToLowerW(fi.path);

    // Khong danh gia heuristic cho thu muc Windows (file ky bang catalog se bi bao Unsigned sai).
    std::wstring win = ToLowerW(GetEnvW(L"SystemRoot"));
    if (!win.empty() && lp.compare(0, win.size() + 1, win + L"\\") == 0) return r;

    std::wstring name = lp.substr(lp.find_last_of(L'\\') + 1);
    std::wstring ext = ExtOf(name);
    bool isExec = In(ext, kExec), isScript = In(ext, kScript), isDecoy = In(ext, kDecoy);
    if (!isExec && !isScript && !isDecoy) return r;
    r.relevant = true;

    if (fi.size == 0) { r.skipped = true; return r; }
    if (fi.size > maxSize) { r.skipped = true; r.notes.push_back("Bỏ qua: vượt giới hạn dung lượng"); return r; }

    std::string head; DWORD err = 0;
    size_t want = isScript ? 65536 : 1024;
    if (!ReadHead(fi.path, want, head, err)) {
        r.verdict = (err == ERROR_ACCESS_DENIED || err == ERROR_SHARING_VIOLATION || err == ERROR_LOCK_VIOLATION)
                        ? Verdict::AccessDenied : Verdict::ScanError;
        r.error = "Không đọc được file (mã lỗi " + std::to_string(err) + ")";
        return r;
    }

    // 1) EICAR: chuoi kiem thu antivirus chuan, vo hai. Ghep tu manh de file nguon khong tu kich hoat AV.
    static const std::string eicar = std::string("X5O!P%@AP[4\\PZX54(P^)7CC)7}$") +
                                     "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!" + "$H+H*";
    if (fi.size <= 1024 && head.find(eicar) != std::string::npos) {
        r.verdict = Verdict::ConfirmedThreat;
        r.source = "Chữ ký kiểm thử EICAR (tích hợp sẵn)";
        r.reasons.push_back("File chứa chuỗi kiểm thử EICAR (không phải mã độc thật)");
    }

    int score = 0;
    // 2) File thuc thi gia dang tai lieu/anh
    if (isDecoy && head.size() >= 2 && head[0] == 'M' && head[1] == 'Z' && fi.size >= 64) {
        score += 2;
        r.reasons.push_back("Có header PE (MZ) nhưng đuôi file là " + ToUtf8(ext));
    }
    // 3) Duoi kep kieu  ten.pdf.exe
    if (isExec || isScript) {
        std::wstring stem = name.substr(0, name.size() - ext.size());
        if (In(ExtOf(stem), kDocExt)) {
            score += 2;
            r.reasons.push_back("Đuôi kép giả dạng tài liệu: " + ToUtf8(name));
        }
    }
    // 4) Chu ky so
    if (In(ext, kSigExt)) {
        r.sig = CheckSignature(fi.path);
        if (r.sig == SigState::Invalid) {
            score += 2;
            r.reasons.push_back("Chữ ký số không khớp nội dung file (digest mismatch)");
        } else if (r.sig == SigState::Unsigned && InUserWritable(lp)) {
            score += 1;
            r.notes.push_back("Không có chữ ký số, nằm trong thư mục người dùng ghi được");
        } else if (r.sig == SigState::Unsigned) {
            r.notes.push_back("Không có chữ ký số");
        }
    }
    // 5) Script: mau lenh hay gap trong downloader/obfuscation
    if (isScript) {
        std::string t = Lower(head);
        static const char* pats[] = {"-encodedcommand", "frombase64string", "downloadstring", "invoke-expression", "iex("};
        int hits = 0;
        std::string found;
        for (auto p : pats) if (t.find(p) != std::string::npos) { ++hits; found += std::string(found.empty() ? "" : ", ") + p; }
        if (hits >= 2) { score += 2; r.reasons.push_back("Nhiều mẫu lệnh đáng ngờ trong script: " + found); }
        else if (hits == 1) { score += 1; r.notes.push_back("Mẫu lệnh đáng ngờ trong script: " + found); }
        if (InUserWritable(lp)) { score += 1; r.notes.push_back("Script nằm trong thư mục người dùng ghi được"); }
    }

    bool flagged = score >= 2 || r.verdict == Verdict::ConfirmedThreat;
    if (flagged && r.verdict != Verdict::ConfirmedThreat) {
        r.verdict = Verdict::Suspicious;
        r.source = "Heuristic (điểm " + std::to_string(score) + ")";
    }
    // Hash: file thuc thi/script va moi file bi gan co
    if (isExec || isScript || flagged) {
        std::string herr;
        if (!Sha256File(fi.path, r.sha256, herr)) r.error = herr;
    }
    return r;
}

}  // namespace dss

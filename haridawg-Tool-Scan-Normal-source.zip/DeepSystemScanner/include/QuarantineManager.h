#pragma once
#include <string>
#include "Detection.h"

namespace dss {

class QuarantineManager {
public:
    explicit QuarantineManager(const std::wstring& dir);
    bool Quarantine(Detection& d, std::string& msg);
    bool Restore(Detection& d, std::string& msg);
    bool DeletePermanently(Detection& d, std::string& msg);
    static bool IsProtectedPath(const std::wstring& path);
    const std::wstring& Dir() const { return dir_; }
private:
    bool VerifyIdentity(const Detection& d, std::string& msg, std::string& hashOut) const;
    std::wstring dir_;
};

}  // namespace dss

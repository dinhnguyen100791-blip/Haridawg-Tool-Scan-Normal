#pragma once
#include <string>
#include "Util.h"

namespace dss {

struct DefenderStatus {
    bool available = false;
    bool serviceRunning = false;
    std::wstring mpCmdRun;
    std::string note;
};

enum class DefenderResult { Clean, ThreatFound, Error, Timeout };

class DefenderIntegration {
public:
    static DefenderStatus Detect();
    // Quet MOT file bang MpCmdRun.exe (CreateProcessW, khong qua shell). -DisableRemediation: khong tu xu ly.
    static DefenderResult ScanFile(const DefenderStatus& st, const std::wstring& path,
                                   DWORD timeoutMs, std::string& detail);
};

}  // namespace dss

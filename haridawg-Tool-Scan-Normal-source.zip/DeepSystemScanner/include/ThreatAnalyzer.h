#pragma once
#include <string>
#include <vector>
#include "DiskScanner.h"
#include "Detection.h"

namespace dss {

struct AnalysisResult {
    bool relevant = false;     // file thuoc dinh dang can kiem tra
    bool skipped = false;      // bo qua (qua lon, rong...)
    Verdict verdict = Verdict::CleanByScanner;
    std::vector<std::string> reasons;  // bang chung dan toi SUSPICIOUS/CONFIRMED
    std::vector<std::string> notes;    // chi bao yeu, KHONG du de ket luan
    std::string source;
    std::string sha256;
    std::string error;
    SigState sig = SigState::Unknown;
};

// Nguyen tac: mot chi bao yeu (thieu chu ky, nam trong Temp...) KHONG du de bao nghi ngo.
// Can tong diem >= 2 tu cac chi bao doc lap. CONFIRMED chi den tu chu ky da biet (EICAR) hoac Defender.
class ThreatAnalyzer {
public:
    AnalysisResult Analyze(const FileInfo& fi, uint64_t maxSize) const;
};

}  // namespace dss

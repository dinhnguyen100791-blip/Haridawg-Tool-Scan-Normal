#pragma once
#include <atomic>
#include <functional>
#include <vector>
#include "DefenderIntegration.h"
#include "DiskScanner.h"
#include "ScanLogger.h"
#include "ThreatAnalyzer.h"

namespace dss {

struct ScanOptions {
    std::vector<std::wstring> roots;
    uint64_t maxFileSize = 200ull * 1024 * 1024;
    bool useDefender = true;
    bool verbose = false;
    DWORD defenderTimeoutMs = 120000;
};

struct ScanStats {
    std::atomic<uint64_t> filesSeen{0}, analyzed{0}, skipped{0}, accessDenied{0}, errors{0};
    std::atomic<bool> cancelled{false};
};

class ScannerCore {
public:
    ScannerCore(ScanLogger& log, ScanOptions opt) : log_(log), opt_(std::move(opt)) {}
    void Run();
    std::vector<Detection>& Detections() { return dets_; }
    const ScanStats& Stats() const { return stats_; }
    std::function<void(const Detection&)> onDetection;  // goi tu thread quet

private:
    void HandleFile(const FileInfo& fi);
    void AddDetection(const FileInfo& fi, AnalysisResult& r);
    ScanLogger& log_;
    ScanOptions opt_;
    ThreatAnalyzer analyzer_;
    DefenderStatus def_;
    std::vector<Detection> dets_;
    ScanStats stats_;
};

}  // namespace dss

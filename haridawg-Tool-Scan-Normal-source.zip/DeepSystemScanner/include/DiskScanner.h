#pragma once
#include <functional>
#include <string>
#include <vector>
#include "Util.h"

namespace dss {

struct FileInfo {
    std::wstring path;
    uint64_t size = 0;
    DWORD attrs = 0;
};

class DiskScanner {
public:
    struct Callbacks {
        std::function<void(const FileInfo&)> onFile;
        std::function<void(const std::wstring&, DWORD)> onError;  // thu muc/file khong doc duoc
    };
    // Cac o co dinh + removable (khong gom o mang).
    static std::vector<std::wstring> EnumerateRoots();
    // Duyet khong de quy (stack tu quan ly), bo qua reparse point de tranh vong lap/OneDrive placeholder.
    void Walk(const std::wstring& root, const Callbacks& cb) const;
};

}  // namespace dss

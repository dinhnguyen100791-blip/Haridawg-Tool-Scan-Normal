#pragma once
#include <cstdio>
#include <functional>
#include <mutex>
#include <string>
#include "Detection.h"

namespace dss {

class ScanLogger {
public:
    explicit ScanLogger(const std::wstring& logDir, uint64_t maxBytes = 5u * 1024 * 1024);
    ~ScanLogger();
    ScanLogger(const ScanLogger&) = delete;
    ScanLogger& operator=(const ScanLogger&) = delete;

    void Log(const char* tag, const std::string& msg);  // [HH:MM:SS] [TAG] msg
    void Raw(const std::string& block);                 // khong gan timestamp
    void LogDetection(const Detection& d);
    const std::wstring& LogPath() const { return path_; }
    // GUI nhan moi dong log (goi tu bat ky thread nao, trong khi giu mutex: chi nen PostMessage).
    void SetSink(std::function<void(const std::string&)> s) { std::lock_guard<std::mutex> lk(mu_); sink_ = std::move(s); }

private:
    void Write(const std::string& line);
    void RotateIfNeeded();
    bool Open();
    std::mutex mu_;
    FILE* f_ = nullptr;
    std::wstring dir_, path_;
    uint64_t maxBytes_;
    bool fileFailed_ = false;
    std::function<void(const std::string&)> sink_;
};

}  // namespace dss

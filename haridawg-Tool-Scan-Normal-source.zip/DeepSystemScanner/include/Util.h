#pragma once
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <atomic>
#include <cstdint>
#include <string>

namespace dss {

extern std::atomic<bool> g_cancel;  // dat boi Ctrl+C

std::string ToUtf8(const std::wstring& w);
std::wstring FromUtf8(const std::string& s);
std::string NowTime();   // HH:MM:SS
std::string NowStamp();  // yyyymmdd_hhmmss
std::wstring ToLowerW(std::wstring s);
std::wstring GetEnvW(const wchar_t* name);
bool EnsureDir(const std::wstring& path);
bool PathExists(const std::wstring& path);

// RAII cho HANDLE
class UniqueHandle {
public:
    UniqueHandle() = default;
    explicit UniqueHandle(HANDLE h) : h_(h) {}
    UniqueHandle(const UniqueHandle&) = delete;
    UniqueHandle& operator=(const UniqueHandle&) = delete;
    ~UniqueHandle() { reset(); }
    void reset(HANDLE h = nullptr) {
        if (h_ && h_ != INVALID_HANDLE_VALUE) CloseHandle(h_);
        h_ = h;
    }
    bool valid() const { return h_ && h_ != INVALID_HANDLE_VALUE; }
    HANDLE get() const { return h_; }
private:
    HANDLE h_ = nullptr;
};

bool Sha256Buffer(const void* data, size_t len, std::string& hexOut);
bool Sha256File(const std::wstring& path, std::string& hexOut, std::string& err);

enum class SigState { Signed, Unsigned, Invalid, Unknown };
SigState CheckSignature(const std::wstring& path);
const char* SigName(SigState s);

}  // namespace dss

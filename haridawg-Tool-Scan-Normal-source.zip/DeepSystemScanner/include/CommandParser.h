#pragma once
// Parser lenh menu: chi nhan  Q|D|S|V|R <so[,so...]>,  L,  0.  Khong bao gio dua chuoi nguoi dung vao shell.
#include <cctype>
#include <string>
#include <vector>

namespace dss {

struct Command {
    char op = 0;
    std::vector<int> ids;
};

inline bool ParseCommand(const std::string& line, int maxId, Command& out, std::string& err) {
    out = Command{};
    size_t b = line.find_first_not_of(" \t\r\n");
    if (b == std::string::npos) { err = "Lệnh trống"; return false; }
    size_t e = line.find_last_not_of(" \t\r\n");
    std::string s = line.substr(b, e - b + 1);
    char op = (char)std::toupper((unsigned char)s[0]);
    std::string rest = s.substr(1);

    if (op == '0' || op == 'L') {
        if (!rest.empty()) { err = "Lệnh này không nhận tham số"; return false; }
        out.op = op;
        return true;
    }
    if (op != 'Q' && op != 'D' && op != 'S' && op != 'V' && op != 'R') {
        err = "Lệnh không hợp lệ"; return false;
    }
    if (rest.empty() || !std::isspace((unsigned char)rest[0])) {
        err = "Cú pháp: <lệnh> <số>[,<số>...]"; return false;
    }
    std::vector<int> ids;
    long cur = 0; int digits = 0;
    auto flush = [&]() -> bool {
        if (digits == 0) return true;
        if (cur < 1 || cur > maxId) { err = "Số " + std::to_string(cur) + " nằm ngoài danh sách"; return false; }
        bool dup = false;
        for (int x : ids) if (x == (int)cur) dup = true;
        if (!dup) ids.push_back((int)cur);
        cur = 0; digits = 0;
        return true;
    };
    for (size_t i = 1; i < s.size(); ++i) {
        unsigned char c = (unsigned char)s[i];
        if (std::isdigit(c)) {
            if (++digits > 6) { err = "Số quá dài"; return false; }
            cur = cur * 10 + (c - '0');
        } else if (c == ',' || std::isspace(c)) {
            if (!flush()) return false;
        } else { err = "Ký tự không hợp lệ trong danh sách số"; return false; }
    }
    if (!flush()) return false;
    if (ids.empty()) { err = "Thiếu số thứ tự"; return false; }
    if (ids.size() > 64) { err = "Tối đa 64 mục mỗi lệnh"; return false; }
    out.op = op;
    out.ids = ids;
    return true;
}

}  // namespace dss

#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace dss {

enum class Verdict { CleanByScanner, Suspicious, ConfirmedThreat, AccessDenied, Unsupported, ScanError };
enum class Status { AwaitingReview, Quarantined, Deleted, Skipped, Restored, ActionFailed };

inline const char* VerdictName(Verdict v) {
    switch (v) {
        case Verdict::CleanByScanner: return "CLEAN_BY_SCANNER";
        case Verdict::Suspicious: return "SUSPICIOUS";
        case Verdict::ConfirmedThreat: return "CONFIRMED_THREAT";
        case Verdict::AccessDenied: return "ACCESS_DENIED";
        case Verdict::Unsupported: return "UNSUPPORTED";
        default: return "SCAN_ERROR";
    }
}

inline const char* StatusName(Status s) {
    switch (s) {
        case Status::AwaitingReview: return "Chờ người dùng xem xét";
        case Status::Quarantined: return "Đã cách ly";
        case Status::Deleted: return "Đã xóa";
        case Status::Skipped: return "Đã bỏ qua";
        case Status::Restored: return "Đã khôi phục";
        default: return "Thao tác thất bại";
    }
}

struct Detection {
    int id = 0;
    std::wstring path;
    std::string sha256;
    Verdict verdict = Verdict::Suspicious;
    std::vector<std::string> reasons;
    std::string source;
    uint64_t size = 0;
    Status status = Status::AwaitingReview;
    std::wstring quarantinePath;
};

}  // namespace dss

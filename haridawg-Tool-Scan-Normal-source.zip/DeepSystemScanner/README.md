# haridawg Tool Scan Normal

<p align="center"><img src="assets/logo.png" width="160" alt="logo"></p>

Gồm 2 chương trình dùng chung một lõi quét:

- **haridawgToolScanNormal.exe** - giao diện đồ họa (nền "mưa ký tự", danh sách phát hiện có tích chọn, nút Cách ly / Khôi phục / Xóa / Bỏ qua / Chi tiết).
- **DeepSystemScanner.exe** - bản dòng lệnh (CMD/PowerShell).

## Tải về qua GitHub
1. Push repo này lên GitHub (nhánh `main`). Actions tự build x64 và x86 (Win32).
2. Vào tab **Actions** -> lần chạy mới nhất -> mục **Artifacts** -> tải zip.
3. Muốn có trang Releases: `git tag v1.0.0 && git push --tags`.

exe build bằng CRT tĩnh, không cần cài VC++ Redistributable.

## Dùng GUI
Chọn thư mục (hoặc để trống = toàn bộ ổ đĩa) -> **Bắt đầu quét**. Tích chọn file trong danh sách rồi bấm hành động.
Không tích gì thì thao tác áp dụng cho dòng đang chọn. Nhấp đúp để xem chi tiết.
Log: `%LOCALAPPDATA%\haridawgToolScanNormal\logs`, khu cách ly: `...\Quarantine`.

---

# DeepSystemScanner (bản tối thiểu)

Công cụ console C++17 / Win32: duyệt ổ đĩa, SHA-256, kiểm tra chữ ký, heuristic có ngưỡng,
xác nhận qua Microsoft Defender, log trực tiếp, menu cách ly / khôi phục / xóa an toàn.

## Build (MSVC + CMake)
Mở "x64 Native Tools Command Prompt for VS" (hoặc x86 cho Windows 32-bit):

    cmake -S . -B build -A x64
    cmake --build build --config Release
    ctest --test-dir build -C Release

Với GCC/MinGW: `cmake -S . -B build -G "MinGW Makefiles"`.

## Chạy
    build\Release\DeepSystemScanner.exe --path C:\Users\Public\scan-test --verbose
    build\Release\DeepSystemScanner.exe                (quét mọi ổ cố định/removable)
    build\Release\DeepSystemScanner.exe --no-defender --max-mb 50

Không cần quyền admin. Chạy PowerShell/CMD thường thì vùng bị từ chối sẽ được ghi nhận ACCESS_DENIED;
chạy admin sẽ quét được nhiều hơn. Log: `%LOCALAPPDATA%\DeepSystemScanner\logs\scan.log` (xoay vòng 5 MB),
khu cách ly: `%LOCALAPPDATA%\DeepSystemScanner\Quarantine`.

## Bộ test an toàn (file vô hại)
Tạo thư mục `C:\Users\Public\scan-test` rồi:

    echo hello > C:\Users\Public\scan-test\invoice.pdf.exe     (đuôi kép -> SUSPICIOUS)
    python -c "open(r'C:\Users\Public\scan-test\pic.jpg','wb').write(b'MZ'+b'\0'*200)"   (header MZ trong .jpg -> SUSPICIOUS)

Rồi quét `--path C:\Users\Public\scan-test`, thử `V 1`, `Q 1`, `R 1`, `D 2`.
Thử thêm file EICAR chuẩn (tải từ eicar.org) nếu Defender cho phép lưu: sẽ ra CONFIRMED_THREAT.

## Heuristic (cố ý thận trọng)
Một chỉ báo yếu (thiếu chữ ký, nằm trong Temp, CPU cao) KHÔNG đủ để báo. Cần tổng điểm >= 2:
header MZ giả đuôi ảnh/tài liệu (2), đuôi kép (2), chữ ký không khớp nội dung (2),
nhiều mẫu lệnh downloader trong script (2), các chỉ báo yếu (1). CONFIRMED_THREAT chỉ đến từ
chuỗi EICAR hoặc Defender.

## Giới hạn hiện tại
- Chưa có: quét tiến trình/RAM, SystemMonitor, SystemAuditor, phân tích file nén, ThreatAnalyzer theo YARA/hash feed.
- Thư mục Windows bị bỏ qua heuristic (file ký bằng catalog sẽ bị báo Unsigned sai); dùng Defender cho vùng đó.
- Đường dẫn dài hơn MAX_PATH bị bỏ qua và ghi SCAN_ERROR.
- Defender gọi qua `MpCmdRun.exe -Scan -ScanType 3 -File`, chỉ cho file bị heuristic gắn cờ (không quét cả đĩa qua Defender).
  Cách đọc kết quả (exit code + chuỗi "threat") cần kiểm tra lại trên từng bản Windows/ngôn ngữ; không nhận ra thì coi là lỗi, không đoán.
- Khôi phục (`R`) chỉ cho file cách ly trong cùng phiên; file .quar + .meta vẫn nằm trên đĩa để khôi phục tay.
- Windows 7: dùng CNG/BCrypt, WinVerifyTrust, FindExInfoBasic (có fallback). Defender/MSE trên Win7 thường không có MpCmdRun
  ở đường dẫn trên -> báo UNSUPPORTED, chỉ chạy heuristic. Chưa kiểm thử thực tế trên các bản Windows: cần bạn chạy bảng test.

#include <cstdio>
#include <string>
#include "Util.h"
using namespace dss;

int main() {
    std::string h;
    bool ok = Sha256Buffer("abc", 3, h) &&
              h == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    std::string e;
    ok = ok && Sha256Buffer("", 0, e) &&
         e == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    std::printf(ok ? "OK\n" : "FAILED\n");
    return ok ? 0 : 1;
}

#include <cstdio>
#include "CommandParser.h"
using namespace dss;

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

int main() {
    Command c; std::string e;
    CHECK(ParseCommand("Q 1,2", 5, c, e) && c.op == 'Q' && c.ids.size() == 2);
    CHECK(ParseCommand("q 3 4", 5, c, e) && c.ids.size() == 2);
    CHECK(ParseCommand("  D 2  ", 5, c, e) && c.op == 'D' && c.ids[0] == 2);
    CHECK(ParseCommand("Q 1,1,1", 5, c, e) && c.ids.size() == 1);
    CHECK(ParseCommand("0", 5, c, e) && c.op == '0');
    CHECK(ParseCommand("L", 5, c, e) && c.op == 'L');
    CHECK(!ParseCommand("Q 6", 5, c, e));
    CHECK(!ParseCommand("Q 0", 5, c, e));
    CHECK(!ParseCommand("Q", 5, c, e));
    CHECK(!ParseCommand("Q1", 5, c, e));
    CHECK(!ParseCommand("Q 1; del *", 5, c, e));
    CHECK(!ParseCommand("X 1", 5, c, e));
    CHECK(!ParseCommand("", 5, c, e));
    CHECK(!ParseCommand("L 1", 5, c, e));
    CHECK(!ParseCommand("Q 99999999", 5, c, e));
    std::printf(fails ? "FAILED\n" : "OK\n");
    return fails;
}
